from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
# from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken


User = get_user_model()

#--register mode-----------------------------------
class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(
        write_only=True,
        required=True,
        validators=[validate_password]
    )

    password2 = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = (
            'email',
            'username',
            'password',
            'password2',
        )

    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError(
                {"password": "Passwords do not match"}
            )

        return attrs

    def create(self, validated_data):
        validated_data.pop('password2')

        user = User.objects.create_user(
            email=validated_data['email'],
            username=validated_data['username'],
            password=validated_data['password']
        )

        return user
    


#--login mode--------------------------------------
class LoginSerializer(serializers.Serializer):

    identifier = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):

        identifier = attrs.get('identifier')
        password = attrs.get('password')
        user = User.objects.filter(email=identifier).first()

        if not user:
            user = User.objects.filter(username=identifier).first()

        if user and user.check_password(password):

            refresh = RefreshToken.for_user(user)

            return {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'username': user.username,
                    'created_at': user.date_joined.isoformat(),
                }
            }

        raise serializers.ValidationError(
            "Invalid credentials"
        )
    
#--logout------------------------------------------
class LogoutSerializer(serializers.Serializer):
    
    refresh = serializers.CharField()
    def save(self):
        token = RefreshToken(self.validated_data['refresh'])
        token.blacklist()

#--meview/profile------------------------------------------
class MeSerializer(serializers.ModelSerializer):
    created_at = serializers.DateTimeField(source='date_joined', read_only=True)

    class Meta:
        model = User
        fields = (
            'id',
            'email',
            'username',
            'created_at',
        )
        read_only_fields = ('id', 'created_at')

    def validate_email(self, value):
        user = self.instance

        if User.objects.exclude(id=user.id).filter(email=value).exists():
            raise serializers.ValidationError("This email is already used.")

        return value

    def validate_username(self, value):
        user = self.instance

        if User.objects.exclude(id=user.id).filter(username=value).exists():
            raise serializers.ValidationError("This username is already used.")

        return value
